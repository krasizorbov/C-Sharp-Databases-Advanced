﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=DESKTOP-H5R51FC\SQLEXPRESS01;Database=BookShop;Integrated Security=True;";
    }
}
