﻿using System;

namespace CarDealer.Dtos.Import
{
    internal class xmlTypeAttribute : Attribute
    {
    }
}